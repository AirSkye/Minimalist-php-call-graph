#ifndef COMBINE_LETTERS_H
#define COMBINE_LETTERS_H

// Prints all combinations of a string.
void combine_letters(const char *letters, int len);

#endif
